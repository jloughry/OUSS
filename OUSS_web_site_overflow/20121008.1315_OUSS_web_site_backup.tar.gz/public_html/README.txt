12th May 2011 (rjl): The files 'oxford.html' and 'doctorow.html'
are stand-alone web pages for the Cory Doctorow talk on 18th May.
I promised to maintain them against broken links forever.
